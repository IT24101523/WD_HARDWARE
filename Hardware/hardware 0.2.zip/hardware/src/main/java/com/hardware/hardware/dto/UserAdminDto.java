package com.hardware.hardware.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserAdminDto {

    private Long id;

    @NotBlank(message = "Username is required")
    @Size(min = 3, max = 50, message = "Username must be between 3 and 50 characters")
    private String username;

    @NotBlank(message = "Email is required")
    @Email(message = "Please provide a valid email address")
    private String email;

    // Optional on edit, required when creating a new user
    private String password;

    @NotBlank(message = "Full Name is required")
    private String fullName;

    private String phone;
    private String address;

    @NotBlank(message = "Role is required")
    @Builder.Default
    private String role = "ROLE_CUSTOMER";
}
