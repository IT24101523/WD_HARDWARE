package com.hardware.hardware.service;

import com.hardware.hardware.dto.PasswordUpdateDto;
import com.hardware.hardware.dto.ProfileUpdateDto;
import com.hardware.hardware.dto.UserAdminDto;
import com.hardware.hardware.dto.UserRegistrationDto;
import com.hardware.hardware.model.User;
import com.hardware.hardware.repository.CartItemRepository;
import com.hardware.hardware.repository.OrderRepository;
import com.hardware.hardware.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final CartItemRepository cartItemRepository;
    private final OrderRepository orderRepository;
    private final PasswordEncoder passwordEncoder;

    public List<User> getAllUsers() {
        return userRepository.findAllByOrderByCreatedAtDesc();
    }

    public List<User> getStaffUsers() {
        return userRepository.findByRoleNotOrderByCreatedAtDesc("ROLE_CUSTOMER");
    }

    public List<User> getCustomerUsers() {
        return userRepository.findByRoleOrderByCreatedAtDesc("ROLE_CUSTOMER");
    }

    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    @Transactional
    public User registerUser(UserRegistrationDto dto) {
        if (userRepository.existsByUsername(dto.getUsername())) {
            throw new IllegalArgumentException("Username '" + dto.getUsername() + "' is already taken.");
        }
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("Email '" + dto.getEmail() + "' is already registered.");
        }

        String role = dto.getRole();
        if (role == null || role.isBlank()) {
            role = "ROLE_CUSTOMER";
        } else if (!role.startsWith("ROLE_")) {
            role = "ROLE_" + role.toUpperCase();
        }

        User user = User.builder()
                .username(dto.getUsername().trim())
                .email(dto.getEmail().trim().toLowerCase())
                .password(passwordEncoder.encode(dto.getPassword()))
                .fullName(dto.getFullName().trim())
                .phone(dto.getPhone() != null ? dto.getPhone().trim() : "")
                .address(dto.getAddress() != null ? dto.getAddress().trim() : "")
                .role(role)
                .build();

        return userRepository.save(user);
    }

    @Transactional
    public User saveOrUpdateUserByAdmin(UserAdminDto dto) {
        if (dto.getId() != null) {
            // Update existing user
            if (userRepository.existsByUsernameAndIdNot(dto.getUsername().trim(), dto.getId())) {
                throw new IllegalArgumentException("Username '" + dto.getUsername().trim() + "' is already taken by another account.");
            }
            if (userRepository.existsByEmailAndIdNot(dto.getEmail().trim().toLowerCase(), dto.getId())) {
                throw new IllegalArgumentException("Email '" + dto.getEmail().trim() + "' is already registered to another account.");
            }

            User user = userRepository.findById(dto.getId())
                    .orElseThrow(() -> new IllegalArgumentException("User not found with ID: " + dto.getId()));

            user.setUsername(dto.getUsername().trim());
            user.setEmail(dto.getEmail().trim().toLowerCase());
            user.setFullName(dto.getFullName().trim());
            user.setPhone(dto.getPhone() != null ? dto.getPhone().trim() : "");
            user.setAddress(dto.getAddress() != null ? dto.getAddress().trim() : "");

            String role = dto.getRole();
            if (role != null && !role.isBlank()) {
                if (!role.startsWith("ROLE_")) {
                    role = "ROLE_" + role.toUpperCase();
                }
                user.setRole(role);
            }

            // Update password only if non-blank provided
            if (dto.getPassword() != null && !dto.getPassword().trim().isEmpty()) {
                if (dto.getPassword().trim().length() < 6) {
                    throw new IllegalArgumentException("Password must be at least 6 characters.");
                }
                user.setPassword(passwordEncoder.encode(dto.getPassword().trim()));
            }

            return userRepository.save(user);
        } else {
            // Create new user
            if (userRepository.existsByUsername(dto.getUsername().trim())) {
                throw new IllegalArgumentException("Username '" + dto.getUsername().trim() + "' is already taken.");
            }
            if (userRepository.existsByEmail(dto.getEmail().trim().toLowerCase())) {
                throw new IllegalArgumentException("Email '" + dto.getEmail().trim() + "' is already registered.");
            }
            if (dto.getPassword() == null || dto.getPassword().trim().length() < 6) {
                throw new IllegalArgumentException("Password is required and must be at least 6 characters.");
            }

            String role = dto.getRole();
            if (role == null || role.isBlank()) {
                role = "ROLE_CUSTOMER";
            } else if (!role.startsWith("ROLE_")) {
                role = "ROLE_" + role.toUpperCase();
            }

            User user = User.builder()
                    .username(dto.getUsername().trim())
                    .email(dto.getEmail().trim().toLowerCase())
                    .password(passwordEncoder.encode(dto.getPassword().trim()))
                    .fullName(dto.getFullName().trim())
                    .phone(dto.getPhone() != null ? dto.getPhone().trim() : "")
                    .address(dto.getAddress() != null ? dto.getAddress().trim() : "")
                    .role(role)
                    .build();

            return userRepository.save(user);
        }
    }

    @Transactional
    public void deleteUserByAdmin(Long id, String currentAdminUsername) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found with ID: " + id));

        if (user.getUsername().equalsIgnoreCase(currentAdminUsername)) {
            throw new IllegalArgumentException("Security Protection: You cannot delete your currently active administrator account!");
        }

        long orderCount = orderRepository.countByUserId(id);
        if (orderCount > 0) {
            throw new IllegalArgumentException("Cannot delete user '" + user.getUsername() + "' because they have " + orderCount + " order records in the database. You may change their role instead.");
        }

        // Safely clear cart items before deletion
        cartItemRepository.deleteByUserId(id);

        userRepository.delete(user);
    }

    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    @Transactional
    public User updateUserProfile(User user, ProfileUpdateDto dto) {
        if (!user.getEmail().equalsIgnoreCase(dto.getEmail().trim())) {
            if (userRepository.existsByEmail(dto.getEmail().trim())) {
                throw new IllegalArgumentException("Email '" + dto.getEmail() + "' is already in use by another account.");
            }
        }
        user.setFullName(dto.getFullName().trim());
        user.setEmail(dto.getEmail().trim().toLowerCase());
        user.setPhone(dto.getPhone() != null ? dto.getPhone().trim() : "");
        user.setAddress(dto.getAddress() != null ? dto.getAddress().trim() : "");
        return userRepository.save(user);
    }

    @Transactional
    public void updateUserPassword(User user, PasswordUpdateDto dto) {
        if (!passwordEncoder.matches(dto.getCurrentPassword(), user.getPassword())) {
            throw new IllegalArgumentException("Your current password is incorrect. Please try again.");
        }
        if (!dto.getNewPassword().equals(dto.getConfirmPassword())) {
            throw new IllegalArgumentException("New password and confirm password do not match.");
        }
        user.setPassword(passwordEncoder.encode(dto.getNewPassword()));
        userRepository.save(user);
    }
}
