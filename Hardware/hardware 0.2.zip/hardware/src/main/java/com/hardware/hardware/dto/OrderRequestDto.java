package com.hardware.hardware.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderRequestDto {

    @NotBlank(message = "Fulfillment type is required (PICKUP or DELIVERY)")
    private String fulfillmentType; // 'PICKUP' or 'DELIVERY'

    private String firstName;
    private String lastName;
    private String companyName;
    private String city;
    private String streetAddress;
    private String apartment;
    private String postcode;
    private String email;
    private String orderNotes;

    private String shippingAddress;
    private String phone;
    private BigDecimal distanceKm;
    private BigDecimal latitude;
    private BigDecimal longitude;

    @NotBlank(message = "Payment method is required")
    private String paymentMethod; // 'COD' or 'CARD' or 'BANK'

    // Simulated card fields
    private String cardNumber;
    private String cardExpiry;
    private String cardCvc;
}
