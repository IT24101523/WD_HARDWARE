package com.hardware.hardware.config;

import com.hardware.hardware.model.User;
import com.hardware.hardware.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        ensureUser("admin", "admin@hardware.com", "admin123", "Super Admin", "+94 77 123 4567", "Main Hardware Hub, Colombo", "ROLE_ADMIN");
        ensureUser("inventory", "inventory@hardware.com", "admin123", "Inventory Control Officer", "+94 77 888 1122", "Stock Yard, Colombo", "ROLE_INVENTORY_OFFICER");
        ensureUser("fleet", "fleet@hardware.com", "admin123", "Fleet Logistics Officer", "+94 77 999 3344", "Dispatch Yard, Colombo", "ROLE_FLEET_OFFICER");
        ensureUser("customer", "customer@hardware.com", "customer123", "John Silva", "+94 71 987 6543", "123 Temple Road, Nugegoda", "ROLE_CUSTOMER");
        ensureUser("kamal", "kamal@hardware.com", "kamal123", "Kamal Perera", "+94 76 555 1234", "45 Main Street, Galle", "ROLE_CUSTOMER");
    }

    private void ensureUser(String username, String email, String rawPassword, String fullName, String phone, String address, String role) {
        userRepository.findByUsername(username).ifPresentOrElse(
            user -> {
                // Ensure default account credentials match rawPassword
                if (!passwordEncoder.matches(rawPassword, user.getPassword())) {
                    user.setPassword(passwordEncoder.encode(rawPassword));
                    user.setRole(role);
                    userRepository.save(user);
                }
            },
            () -> {
                User user = User.builder()
                        .username(username)
                        .email(email)
                        .password(passwordEncoder.encode(rawPassword))
                        .fullName(fullName)
                        .phone(phone)
                        .address(address)
                        .role(role)
                        .build();
                userRepository.save(user);
            }
        );
    }
}
